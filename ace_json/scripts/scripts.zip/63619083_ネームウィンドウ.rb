#===========================================================================

# ◆ A1 Scripts ◆

#    ネームウィンドウ（RGSS2/RGSS3共用）

#

# バージョン   ： 2.40 (2012/01/19)

# 作者         ： A1

# URL　　　　　： http://a1tktk.web.fc2.com/

#---------------------------------------------------------------------------

# 機能：

# ・ネームウィンドウを表示します

#---------------------------------------------------------------------------

# 更新履歴　　 ：2011/12/15 Ver1.00 リリース

#         　　 ：2011/12/29 Ver1.10 アクター名表示対応

#         　　 ：2011/12/30 Ver2.00 左右顔グラフィック対応

#         　　 ：2011/12/30 Ver2.00 表示位置「上」対応

#         　　 ：2011/12/30 Ver2.10 RGSS2対応

#         　　 ：2011/12/30 Ver2.11 名前が切り替わる度にウィンドウを閉じる不具合を修正

#         　　 ：2012/01/02 Ver2.20 同じ顔グラフィックの別名表示機能追加

#         　　 ：2012/01/02 Ver2.20 表示名の直接指定機能追加

#         　　 ：2012/01/02 Ver2.30 A1共通スクリプトVer3.30対応

#         　　 ：2012/01/19 Ver2.40 バトルネームウィンドウ対応

#---------------------------------------------------------------------------

# 設置場所      

#　　A1共通スクリプトより下

#　　(左右顔グラフィックスクリプトより下)

#

# 必要スクリプト

#    A1共通スクリプトVer3.30以上

#---------------------------------------------------------------------------

# 使い方

#　設定項目を設定します

#　

#　  設定項目の「表示する名前」を Actor[ID] とすると

#　  IDで指定したアクターの名前を表示します

#　

#　イベントコマンド「注釈」に記述

#

#　　ネームウィンドウ on|off

#      表示の on/off を切り替えます

#

#    NWインデックス index

#      同じ顔グラフィックに複数の名前を配列で登録している場合

#      次に表示するネームウィンドウを指定した index の名前を使用します

#      省略時には 0番目 の名前を使用します

#

#    NW名前指定 Name

#      次に表示するネームウィンドウに Name を使用します

#      顔グラフィックなしでも表示されます

#==============================================================================

$imported ||= {}

$imported["A1_Name_Window"] = true

if $imported["A1_Common_Script"]

old_common_script("ネームウィンドウ", "3.30") if common_version < 3.30

#==============================================================================

# ■ 設定項目

#==============================================================================

module A1_System::NameWindow



  #--------------------------------------------------------------------------

  # ネームウィンドウを使用するクラス

  #--------------------------------------------------------------------------

  USE_NAME_WINDOW_CLASS = [Window_Message]

  

  #--------------------------------------------------------------------------

  # ネームウィンドウのフォント

  #--------------------------------------------------------------------------

  NAME_FONT = "UmePlus Gothic"

  

  #--------------------------------------------------------------------------

  # 長い名前の時に左(右)に寄せる

  #--------------------------------------------------------------------------

  FIX_LONG_NAME = false

  

  #--------------------------------------------------------------------------

  # 顔グラフィックと名前の対応

  #

  #  "[ファイル名]_[Index]" => "表示する名前" ※Index毎に設定

  #  "[ファイル名]"         => "表示する名前" ※該当ファイル全てに適用

  #                            "Actor[ID]"    ※該当するIDのアクター名を表示

  #--------------------------------------------------------------------------

  NAME_LIST = {

    "aka"    => "Czerwony Kapturek",

    "ri-hu"    => "Wróżka Leaf",

    "alice"    => "Alicja",

    "alice2"    => "Alicja",

    "jnnu"    => "Rycerz Joanna",

    "doro"    => "Czarownica Dorota",

    "eriza"    => "Dama Dusz Elżbieta",

    "eruma"    => "Elma Dziewczynka z Zapałkami",

    "beru"    => "Piękna Belle",

    "biku"    => "Służka Wiktoria",

    "gu-su"    => "Bogata Gęś Goose",

    "kata"    => "Święta Katarina",

    "miranda"    => "Mroczna Miranda",

    "kaeru"    => "Księżniczka Żaba",

    "nin"    => "Syrena",

    "lap"    => "Roszpunka",

    "sira"    => "Królewna Śnieżka",

    "sin"    => "Kopciuszek",

    "poro"    => "Poro",

    "ri-hu2"    => "Mary Sue",

    "maria"    => "Marianna",

    "hen"    => "Jaś",

    "gure"    => "Małgosia",

    "ba"    => "Mroczny Sędzia Baphomet",

  }

end

#==============================================================================

# ■ Cache

#------------------------------------------------------------------------------

# 　各種グラフィックを読み込み、Bitmap オブジェクトを作成、保持するモジュール

# です。読み込みの高速化とメモリ節約のため、作成した Bitmap オブジェクトを内部

# のハッシュに保存し、同じビットマップが再度要求されたときに既存のオブジェクト

# を返すようになっています。

#==============================================================================



module Cache

  #--------------------------------------------------------------------------

  # ○ ネームウィンドウ用ビットマップの取得

  #--------------------------------------------------------------------------

  def self.name_bitmap(name)

    return load_name_bitmap(name)

  end

  #--------------------------------------------------------------------------

  # ○ 名前bitmapの作成

  #--------------------------------------------------------------------------

  def self.load_name_bitmap(name)

    @cache ||= {}

    key = [name, "name_window"]

    return @cache[key] if include?(key)

    

    # 計算用ダミービットマップ

    bitmap = Cache.system("")

    bitmap.font.name = A1_System::NameWindow::NAME_FONT

    bitmap.font.size = 16

    tw = bitmap.text_size(name).width + 8

    

    # ビットマップ作成

    bitmap = Bitmap.new(tw, bitmap.font.size + 4)

    bitmap.font.name = A1_System::NameWindow::NAME_FONT

    bitmap.font.size = 16

    bitmap.font.color = Color.new(255,255,255)

    bitmap.draw_text(0, 0, bitmap.width, bitmap.height, name, 1)

    

    @cache[key] = bitmap

    return @cache[key]

  end

end

#==============================================================================

# ■ Window_FaceName

#==============================================================================



class Window_FaceName < Window_Base

  #--------------------------------------------------------------------------

  # ○ オブジェクト初期化

  #--------------------------------------------------------------------------

  def initialize(name, z)

    info = create_name_sprite(name)

    super(0, 0, info[0], info[1])

    self.visible = true

    self.openness = 0

    self.z = z

    skin = Cache.system("Window").clone

    skin.clear_rect(80, 16, 32, 32)

    self.windowskin = skin

    @name_sprite.z = self.z + 10

  end

  #--------------------------------------------------------------------------

  # ○ ネームウィンドウのセットアップ

  #--------------------------------------------------------------------------

  def setup_name_window(name)

    info = create_name_sprite(name)

    self.width  = info[0]

    self.height = info[1]

    create_contents

    @name_sprite.z = self.z + 10

  end

  #--------------------------------------------------------------------------

  # ○ フレーム更新

  #--------------------------------------------------------------------------

  def update

    super

    @name_sprite.visible = self.visible && self.open?

    return unless self.open?

    @name_sprite.update

  end

  #--------------------------------------------------------------------------

  # ○ 解放

  #--------------------------------------------------------------------------

  def dispose

    @name_sprite.bitmap.dispose

    @name_sprite.dispose

    super

  end

  #--------------------------------------------------------------------------

  # ○ ウィンドウを開く

  #--------------------------------------------------------------------------

  def open

    super

    @name_sprite.x = self.x + self.width / 2

    @name_sprite.y = self.y + self.height / 2

  end

  #--------------------------------------------------------------------------

  # ○ スプライトの作成

  #--------------------------------------------------------------------------

  def create_name_sprite(name)

    # ビットマップの取得

    bitmap = Cache.name_bitmap(name)

    

    # スプライト設定

    @name_sprite         = Sprite.new

    @name_sprite.bitmap  = bitmap

    @name_sprite.ox      = bitmap.width / 2

    @name_sprite.oy      = bitmap.height / 2

    @name_sprite.visible = false

    

    return [bitmap.width + 8, bitmap.height + 8]

  end

end

#==============================================================================

# ■ Window_Base

#------------------------------------------------------------------------------

# 　ゲーム中のすべてのウィンドウのスーパークラスです。

#==============================================================================



class Window_Base < Window

  #--------------------------------------------------------------------------

  # ☆ オブジェクト初期化

  #--------------------------------------------------------------------------

  alias a1_name_window_window_base_initialize initialize 

  def initialize(x, y, width, height)

    a1_name_window_window_base_initialize(x, y, width, height)

    create_name_window

  end

  #--------------------------------------------------------------------------

  # ☆ フレーム更新

  #--------------------------------------------------------------------------

  alias a1_name_window_window_base_update update 

  def update

    a1_name_window_window_base_update

    update_name_window

  end

  #--------------------------------------------------------------------------

  # ☆ 顔グラフィックの描画

  #--------------------------------------------------------------------------

  alias a1_name_window_window_base_draw_face draw_face

  def draw_face(face_name, face_index, x, y, size = 96)

    a1_name_window_window_base_draw_face(face_name, face_index, x, y, size)

    show_name_window(face_name, face_index, x, size)

  end

  #--------------------------------------------------------------------------

  # ☆ ウィンドウを閉じる

  #--------------------------------------------------------------------------

  alias a1_name_window_window_base_close close

  def close

    a1_name_window_window_base_close

  end

  #--------------------------------------------------------------------------

  # ☆ 解放

  #--------------------------------------------------------------------------

  alias a1_name_window_window_base_dispose dispose

  def dispose

    a1_name_window_window_base_dispose

    dispose_name_window

  end

  #--------------------------------------------------------------------------

  # ○ ネームウィンドウの解放

  #--------------------------------------------------------------------------

  def dispose_name_window

    @name_windows.values.each {|window| window.dispose }

  end

  #--------------------------------------------------------------------------

  # ○ ネームウィンドウの更新

  #--------------------------------------------------------------------------

  def update_name_window

    @name_windows.values.each {|window| window.update }

  end

  #--------------------------------------------------------------------------

  # ○ ネームウィンドウを使用？

  #--------------------------------------------------------------------------

  def use_name_window?

    A1_System::NameWindow::USE_NAME_WINDOW_CLASS.each {|clas| return true if self.is_a?(clas) }

    return false

  end

  #--------------------------------------------------------------------------

  # ○ ネームウィンドウの作成

  #--------------------------------------------------------------------------

  def create_name_window

    @name_windows = {}

  end

  #--------------------------------------------------------------------------

  # ○ 表示する名前の取得

  #--------------------------------------------------------------------------

  def show_name(face_name, face_index)

    return nil unless $game_system.use_name_window

    name = $game_temp.direct_show_name

    if name.empty?

      return nil if face_name == nil || face_name.empty?

      name = A1_System::NameWindow::NAME_LIST[sprintf("%s_%d", face_name, face_index)]

      name = A1_System::NameWindow::NAME_LIST[face_name] if name == nil

      name = name[$game_temp.name_index] if name.is_a?(Array)

      name = $game_actors[$1.to_i].name if name =~ /Actor\[(\d+)\]/

    end

    $game_temp.name_index       = 0

    $game_temp.direct_show_name = ""

    return name

  end

  #--------------------------------------------------------------------------

  # ○ ネームウィンドウの表示

  #--------------------------------------------------------------------------

  def show_name_window(face_name, face_index, x, size = 96)

    return unless use_name_window?

    name = show_name(face_name, face_index)

    return if name == nil or name.empty?

    @name_windows[name] ||= Window_FaceName.new(name, self.z + 10)

    if x <= Graphics.width / 2

      @name_windows[name].x = x + size + 20

      @name_windows[name].x = 0 if @name_windows[name].x + @name_windows[name].width > Graphics.width / 2 and A1_System::NameWindow::FIX_LONG_NAME

    else

      @name_windows[name].x = Graphics.width - size - @name_windows[name].width 

      @name_windows[name].x = Graphics.width - @name_windows[name].width if @name_windows[name].x < Graphics.width / 2 and A1_System::NameWindow::FIX_LONG_NAME

    end

    @name_windows[name].y = self.y      - 16 if self.y  > 0

    @name_windows[name].y = self.height - 16 if self.y == 0

    @name_windows[name].openness = 255 if self.open?

    @name_windows[name].open

    @name_windows[name].visible = true

  end

  #--------------------------------------------------------------------------

  # ○ ネームウィンドウを閉じる

  #--------------------------------------------------------------------------

  def name_window_close

    @name_windows.values.each {|window| window.close }

  end

  #--------------------------------------------------------------------------

  # ○ ネームウィンドウを非表示

  #--------------------------------------------------------------------------

  def name_window_visible_false

    @name_windows.values.each {|window| window.visible = false }

  end

end

#==============================================================================

# ■ Window_Message

#------------------------------------------------------------------------------

# 　文章表示に使うメッセージウィンドウです。

#==============================================================================



class Window_Message

  #--------------------------------------------------------------------------

  # ○ ウィンドウを閉じる

  #--------------------------------------------------------------------------

  def close

    name_window_close

    super

  end

end

#==============================================================================

# ◆ RGSS3用処理

#==============================================================================

if rgss_version == 3

#==============================================================================

# ■ Window_Message

#------------------------------------------------------------------------------

# 　文章表示に使うメッセージウィンドウです。

#==============================================================================



class Window_Message < Window_Base

  #--------------------------------------------------------------------------

  # ☆ 改ページ処理

  #--------------------------------------------------------------------------

  alias a1_name_window_window_message_new_page new_page 

  def new_page(text, pos)

    name_window_visible_false

    a1_name_window_window_message_new_page(text, pos)

  end

end

#==============================================================================

# ◆ RGSS2用処理

#==============================================================================

elsif rgss_version == 2

#==============================================================================

# ■ Window_Message

#------------------------------------------------------------------------------

# 　文章表示に使うメッセージウィンドウです。

#==============================================================================



class Window_Message < Window_Selectable

  #--------------------------------------------------------------------------

  # ☆ 改ページ処理

  #--------------------------------------------------------------------------

  alias a1_name_window_window_message_new_page new_page 

  def new_page

    name_window_visible_false

    a1_name_window_window_message_new_page

  end

end

#==============================================================================

# ◆ RGSS用処理

#==============================================================================

elsif rgss_version == 1

end

#==============================================================================

# ■ Game_System

#------------------------------------------------------------------------------

# 　システム周りのデータを扱うクラスです。乗り物や BGM などの管理も行います。

# このクラスのインスタンスは $game_system で参照されます。

#==============================================================================



class Game_System

  #--------------------------------------------------------------------------

  # ○ 公開インスタンス変数

  #--------------------------------------------------------------------------

  attr_accessor :use_name_window                # ネームウィンドウ表示フラグ

  #--------------------------------------------------------------------------

  # ☆ オブジェクト初期化

  #--------------------------------------------------------------------------

  alias a1_name_window_game_system_initialize initialize

  def initialize

    a1_name_window_game_system_initialize

    @use_name_window = false

  end

end

#==============================================================================

# ■ Game_Temp

#------------------------------------------------------------------------------

# 　セーブデータに含まれない、一時的なデータを扱うクラスです。このクラスのイン

# スタンスは $game_temp で参照されます。

#==============================================================================



class Game_Temp

  #--------------------------------------------------------------------------

  # ○ 公開インスタンス変数

  #--------------------------------------------------------------------------

  attr_accessor :name_index

  attr_accessor :direct_show_name

  #--------------------------------------------------------------------------

  # ☆ オブジェクト初期化

  #--------------------------------------------------------------------------

  alias a1_name_window_gt_initialize initialize

  def initialize

    a1_name_window_gt_initialize

    @name_index       = 0

    @direct_show_name = ""

  end

end

#==============================================================================

# ■ A1_System::CommonModule

#==============================================================================



class A1_System::CommonModule

  #--------------------------------------------------------------------------

  # ☆ 注釈コマンド定義

  #--------------------------------------------------------------------------

  alias a1_name_window_define_command define_command

  def define_command

    a1_name_window_define_command

    @cmd_108["ネームウィンドウ"] = :name_window

    @cmd_108["NWインデックス"]   = :nw_index

    @cmd_108["NW名前指定"]       = :nw_set_name

  end

end

#==============================================================================

# ■ Game_Interpreter

#------------------------------------------------------------------------------

# 　イベントコマンドを実行するインタプリタです。このクラスは Game_Map クラス、

# Game_Troop クラス、Game_Event クラスの内部で使用されます。

#==============================================================================



class Game_Interpreter

  #--------------------------------------------------------------------------

  # ○ ネームウィンドウ

  #--------------------------------------------------------------------------

  def name_window(params)

    $game_system.use_name_window = params[0] == "on" ? true : false

  end

  #--------------------------------------------------------------------------

  # ○ NWインデックス

  #--------------------------------------------------------------------------

  def nw_index(params)

    $game_temp.name_index = params[0].to_i

  end

  #--------------------------------------------------------------------------

  # ○ NW名前指定

  #--------------------------------------------------------------------------

  def nw_set_name(params)

    $game_temp.direct_show_name = params[0]

  end

end

end